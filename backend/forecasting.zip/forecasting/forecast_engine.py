# backend/forecasting/forecast_engine.py
import random
from .mitre_mapping import MITRE_STAGES, STAGE_NUMBER

USE_MOCK = True  # Member 2/3 ka real model final hone ke baad False karna

def _mock_stage_probabilities():
    probs = {str(i + 1): round(random.uniform(0.05, 0.3), 2) for i in range(len(MITRE_STAGES))}
    # ek stage ko highest bana do taaki current predicted stage clear dikhe
    winner = random.choice(list(probs.keys()))
    probs[winner] = round(random.uniform(0.5, 0.8), 2)
    return probs

def run_forecast():
    if USE_MOCK:
        stage_probabilities = _mock_stage_probabilities()
        winner_num = max(stage_probabilities, key=stage_probabilities.get)
        predicted_stage = MITRE_STAGES[int(winner_num) - 1]
        risk_score = stage_probabilities[winner_num]

        top_features = {
            "Idle Mean": 0.34,
            "Flow IAT Std": 0.28,
            "Idle Max": 0.21,
            "Fwd IAT Max": 0.11,
            "TotLen Fwd Pkts": 0.06
        }  # Member 3 ke real SHAP output se replace hoga

        forecast_series = [round(random.uniform(0.1, 0.9), 2) for _ in range(10)]

        kpis = {
            "threats": random.randint(1, 50),
            "packets": f"{random.randint(1, 20)}.{random.randint(0,9)}K",
            "blocked": random.randint(10, 1500),
            "confidence": f"{random.randint(80, 95)}%"
        }
    else:
        # real model path — Member 2/3 integrate hone ke baad yahan aayega
        raise NotImplementedError("Real model not connected yet")

    return {
        "risk_score": risk_score,
        "predicted_stage": predicted_stage,
        "stage_probabilities": stage_probabilities,
        "top_features": top_features,
        "forecast_series": forecast_series,
        "kpis": kpis
    }